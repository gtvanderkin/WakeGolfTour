from django.apps import AppConfig


class GolferConfig(AppConfig):
    name = 'golfer'

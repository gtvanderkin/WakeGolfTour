for x in range(0, 18):
    print(x)
